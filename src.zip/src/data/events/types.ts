// src/data/events/types.ts
import { Dialogue } from "../dialogues";
// import { GirlStats } from "../characters";

export type GameplayFlag =
  | "hasMetIris"
  | "hasMetDawn"
  | "hasMetGwen"
  | "hasMetYumi"
  | "hasMetRuby"
  | "firstWorkout"
  | "firstTimeWorked"
  | "firstTimeCookedMeal"
  | "firstTimeStudied"
  | "firstDateCompleted"
  | "iris_first_kiss"
  | "iris_first_date"
  | "iris_first_sex"
  | "dawn_first_sex";

export type EventConditions = {
  // Minimum stat requirements
  minAffection?: number;
  minLust?: number;
  minTrust?: number;
  minLove?: number;
  minMood?: number;

  // Maximum stat requirements (for specific scenarios)
  maxAffection?: number;
  maxLust?: number;

  // Player requirements
  minPlayerIntelligence?: number;
  minPlayerFitness?: number;
  minPlayerStyle?: number;
  minPlayerMoney?: number;

  // Time requirements
  minHour?: number; // Event only triggers after this hour
  maxHour?: number; // Event only triggers before this hour
  specificDay?: string; // Event only on specific day

  // Location requirements
  requiredLocation?: string;

  // Story requirements
  requiredPreviousEvents?: string[]; // Must have completed these events first
  blockedByEvents?: string[]; // Cannot have completed these events

  // Flag requirements
  requiredFlags?: GameplayFlag[];
  blockedByFlags?: GameplayFlag[];
};

export type CharacterEvent = {
  id: string;
  name: string;
  description?: string; // For debugging/admin

  // Requirements to trigger
  conditions: EventConditions;

  // Cooldown in game hours before this event can trigger again
  cooldownHours?: number;

  // Can this event repeat, or is it one-time only?
  repeatable: boolean;

  // Priority (higher priority events check first)
  priority: number;

  // The actual dialogue/content
  dialogue: Dialogue;

  // Optional: Rewards or stat changes after completing event
  rewards?: {
    playerMoney?: number;
    playerStats?: {
      intelligence?: number;
      fitness?: number;
      style?: number;
    };
    setFlags?: GameplayFlag[];
    unlockCharacters?: string[];
  };
  triggerChance?: number; // 0-100, default 100 for backwards compatibility
  triggerLocations?: string[]; // Can trigger at multiple locations
  ambientTrigger?: boolean; // Can trigger without selecting the girl
  chainEvents?: string[]; // Events that can follow this one
  modifyNextEventChance?: { [eventId: string]: number }; // Affect other events
};

export type EventHistory = {
  eventId: string;
  lastTriggered: {
    timestamp: number; // Game time in hours
    metadata?: {
      day?: string;
      hour?: number;
    };
  };
  timesTriggered: number;
};

export type CharacterEventState = {
  characterName: string;
  eventHistory: EventHistory[];
  lastInteractionTime: number; // Total game hours
};
