// src/lib/travel.ts
import { locationGraph } from "@/data/locations";
import type { LocationKey } from "@/types/game";

// Shape that your graph uses for neighbors
export type Neighbor = {
  name: LocationKey | string; // typed key if available; string fallback keeps it flexible
  time: number;
  cost: number;
  image?: string;
  // If you later add energy cost or requirements, add here:
  // energy?: number;
};

// Result enum for simple UI handling
export type TravelResult =
  | "ok"
  | "not-neighbor"
  | "not-enough-money"
  | "not-enough-energy";

export function getNeighbor(
  from: LocationKey,
  to: string | LocationKey
): Neighbor | undefined {
  const neighbors = locationGraph[from] ?? [];
  return neighbors.find((n) => n.name === to);
}

/**
 * Travel between locations with costs and validation.
 *
 * Usage:
 *   const res = travel({
 *     from: currentLocation,
 *     to: destName,
 *     addMoney: (delta) => useGameStore.getState().addMoney(delta),
 *     canSpend: (energy) => useGameStore.getState().canSpend(energy),
 *     spendEnergy: (energy) => useGameStore.getState().spendEnergy(energy),
 *     advanceHours: (h) => useGameStore.getState().advanceHours(h),
 *     setLocation: (k) => useGameStore.getState().setLocation(k),
 *   });
 */
export function travel(opts: {
  from: LocationKey;
  to: LocationKey | string;
  addMoney: (delta: number) => void;
  canSpend?: (energy: number) => boolean;
  spendEnergy?: (energy: number) => boolean;
  advanceHours: (hours: number) => void;
  setLocation: (loc: LocationKey) => void;
}): TravelResult {
  const {
    from,
    to,
    addMoney,
    canSpend,
    spendEnergy,
    advanceHours,
    setLocation,
  } = opts;

  const neighbor = getNeighbor(from, to);
  if (!neighbor) return "not-neighbor";

  // Enforce money
  if (neighbor.cost && neighbor.cost > 0) {
    // negative delta to spend money
    addMoney(-neighbor.cost);
  }

  // If you want energy cost (uncomment + add to Neighbor type/graph)
  // const energyCost = neighbor.energy ?? 0;
  // if (energyCost > 0) {
  //   if (canSpend && !canSpend(energyCost)) return "not-enough-energy";
  //   if (spendEnergy && !spendEnergy(energyCost)) return "not-enough-energy";
  // }

  // Advance time
  if (neighbor.time && neighbor.time > 0) {
    advanceHours(neighbor.time);
  }

  // Move
  setLocation(neighbor.name as LocationKey);
  return "ok";
}
