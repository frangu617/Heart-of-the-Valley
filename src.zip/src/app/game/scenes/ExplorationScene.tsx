"use client";

import Image from "next/image";
import { useMemo, useState, useCallback } from "react";
import { useGameStore } from "@/state/gameStore";
import GoalsPanel from "../ui/GoalsPanel";
import PhoneMenu from "@/components/PhoneMenu";

import { locationGraph } from "@/data/locations";
import { travel } from "@/lib/travel";
import {
  getLocationBackground,
  getAtmosphereOverlay,
} from "@/lib/locationImages";

import type { Girl, PlayerStats as CharPlayerStats } from "@/data/characters";
import {
  girls as ALL_GIRLS,
  defaultPlayerStats as defaultCharPlayer,
} from "@/data/characters";
import type { DayOfWeek } from "@/data/gameConstants";
import type { LocationKey } from "@/types/game";
import { DAYS_OF_WEEK } from "@/data/gameConstants";
import { getCharacterLocation } from "@/data/characterSchedules";

import CharacterOverlay from "@/components/CharacterOverlay";
import type { CharacterEventState, EventHistory } from "@/data/events/types";


export default function ExplorationScene() {
  const [phoneOpen, setPhoneOpen] = useState(false);
  const [activeGirl, setActiveGirl] = useState<Girl | null>(null);
  const [eventStateByGirl, setEventStateByGirl] = useState<
    Record<string, CharacterEventState>
  >({});
  const [charPlayer, setCharPlayer] =
    useState<CharPlayerStats>(defaultCharPlayer);

  const gameState = useGameStore((s) => s.gameState);
  const setGameState = useGameStore((s) => s.setGameState);
  const currentLocation = useGameStore((s) => s.currentLocation);
  const setLocation = useGameStore((s) => s.setLocation);
  const time = useGameStore((s) => s.time);
  const setDialogue = useGameStore((s) => s.setDialogue);
  const { canSpend, spendEnergy, advanceHours, addMoney } = useGameStore();

  const dayOfWeek: DayOfWeek = useMemo(
    () => DAYS_OF_WEEK[((time.dayIndex ?? 1) - 1 + 7) % 7],
    [time.dayIndex]
  );

  const bgSrc = useMemo(
    () => getLocationBackground(currentLocation, time.hour),
    [currentLocation, time.hour]
  );
  const overlayClass = useMemo(
    () => getAtmosphereOverlay(time.hour),
    [time.hour]
  );
  const connected = useMemo(
    () => locationGraph[currentLocation] ?? [],
    [currentLocation]
  );

  const girlsHere: Girl[] = useMemo(() => {
    return ALL_GIRLS.filter((g) => {
      const hasMet = (eventStateByGirl[g.name]?.eventHistory ?? []).some(
        (h) => h.eventId === `${g.name}_first_meeting`
      );
      const loc = getCharacterLocation(g.name, dayOfWeek, time.hour, hasMet);
      return loc === currentLocation;
    });
  }, [ALL_GIRLS, eventStateByGirl, currentLocation, dayOfWeek, time.hour]);

  const handleEventTriggered = useCallback(
    (girlName: string, eventId: string) => {
      setEventStateByGirl((prev) => {
        const prevState = prev[girlName] ?? {
          characterName: girlName,
          eventHistory: [],
          lastInteractionTime: 0,
        };
        const newHist: EventHistory[] = [
          ...prevState.eventHistory,
          {
            eventId,
            lastTriggered: {
              day: dayOfWeek,
              hour: time.hour,
              gameTime: (time.dayIndex ?? 1) * 24 + time.hour,
            },
            timesTriggered: 1,
          },
        ];
        return {
          ...prev,
          [girlName]: {
            ...prevState,
            eventHistory: newHist,
            lastInteractionTime: (time.dayIndex ?? 1) * 24 + time.hour,
          },
        };
      });
    },
    [dayOfWeek, time.dayIndex, time.hour]
  );

  const workShortShift = () => {
    if (!canSpend(10)) return;
    if (spendEnergy(10)) {
      advanceHours(2);
      addMoney(40);
    }
  };
  const workLongShift = () => {
    if (!canSpend(18)) return;
    if (spendEnergy(18)) {
      advanceHours(4);
      addMoney(90);
    }
  };
  const restOneHour = () => {
    if (spendEnergy(-8)) {
      advanceHours(1);
    }
  };

  return (
    <div className="relative mx-auto max-w-6xl p-4 text-white">
      <div className="mb-3 text-white/70">State: {gameState}</div>

      {/* Background */}
      <div className="relative mb-4 h-[420px] w-full overflow-hidden rounded-lg">
        <Image
          src={bgSrc}
          alt={currentLocation}
          fill
          className="object-cover"
          priority
        />
        <div
          className={`absolute inset-0 pointer-events-none ${overlayClass}`}
        />
        <div className="absolute bottom-2 left-1/2 -translate-x-1/2 rounded bg-black/50 px-3 py-1 text-sm font-bold">
          {currentLocation}
        </div>
      </div>

      {/* Characters in this location */}
      <div className="mb-6">
        <h2 className="mb-2 text-lg font-semibold">Characters Here</h2>
        {girlsHere.length === 0 ? (
          <div className="text-sm opacity-75">No one is around right now.</div>
        ) : (
          <div className="flex flex-wrap gap-2">
            {girlsHere.map((g) => (
              <button
                key={g.name}
                onClick={() => setActiveGirl(g)}
                className="rounded bg-white/10 px-3 py-2 text-sm hover:bg-white/20"
              >
                Talk to {g.name}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Nearby locations */}
      <div>
        <h2 className="mb-2 text-lg font-semibold">Nearby Locations</h2>
        <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
          {connected.map((dest) => (
            <button
              key={dest.name}
              // Cast ensures type safety
              onClick={() => {
                const res = travel({
                  from: currentLocation,
                  to: dest.name as LocationKey,
                  addMoney: (delta) => useGameStore.getState().addMoney(delta),
                  canSpend: (energy) =>
                    useGameStore.getState().canSpend(energy),
                  spendEnergy: (energy) =>
                    useGameStore.getState().spendEnergy(energy),
                  advanceHours: (h) => useGameStore.getState().advanceHours(h),
                  setLocation: (k) => useGameStore.getState().setLocation(k),
                });

                // Optional lightweight feedback (replace with your toast/overlay system if you have one)
                if (res === "not-neighbor")
                  console.warn("You can’t travel there directly.");
                if (res === "not-enough-energy")
                  console.warn("Not enough energy to travel.");
                if (res === "not-enough-money")
                  console.warn("Not enough money to travel.");
              }}
              className="group relative overflow-hidden rounded-md border border-white/10 bg-white/5 p-3 text-left hover:bg-white/10"
              title={`Time +${dest.time}h • $${dest.cost}`}
            >
              <div className="relative mb-2 h-24 w-full overflow-hidden rounded">
                <Image
                  src={getLocationBackground(dest.name, time.hour)}
                  alt={dest.name}
                  fill
                  className="object-cover transition-transform duration-200 group-hover:scale-105"
                />
              </div>
              <div className="flex items-center justify-between">
                <div className="text-sm font-semibold">{dest.name}</div>
                <div className="text-xs opacity-80">
                  +{dest.time}h • ${dest.cost}
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Actions + Goals */}
      <div className="mt-6 rounded border border-white/10 bg-black/30 p-6">
        <h2 className="mb-2 text-xl font-bold capitalize">{currentLocation}</h2>
        <p className="opacity-80">
          Spend or restore energy; time advances accordingly.
        </p>

        <div className="mt-4 flex flex-wrap gap-2">
          <button
            onClick={workShortShift}
            className="rounded bg-white/10 px-3 py-2 text-sm hover:bg-white/20"
          >
            Work (Short)
          </button>
          <button
            onClick={workLongShift}
            className="rounded bg-white/10 px-3 py-2 text-sm hover:bg-white/20"
          >
            Work (Long)
          </button>
          <button
            onClick={restOneHour}
            className="rounded bg-white/10 px-3 py-2 text-sm hover:bg-white/20"
          >
            Rest 1h
          </button>
          <button
            onClick={() => setGameState("paused")}
            className="rounded bg-white/10 px-3 py-2 text-sm hover:bg-white/20"
          >
            Pause
          </button>
        </div>

        <div className="mt-6">
          <GoalsPanel />
        </div>
      </div>

      {/* Phone button */}
      <div className="fixed bottom-5 right-5 z-40">
        <button
          onClick={() => setPhoneOpen(true)}
          className="rounded-full bg-purple-600 p-4 text-white shadow-lg hover:bg-purple-700 transition-transform active:scale-95"
          title="Open phone"
        >
          📱
        </button>
      </div>

      {/* Phone overlay */}
      {phoneOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm">
          <div className="relative w-[360px] rounded-xl border border-white/20 bg-black/80 p-4 shadow-lg">
            <PhoneMenu
              player={charPlayer}
              hour={time.hour}
              girls={ALL_GIRLS}
              darkMode
              onClose={() => setPhoneOpen(false)}
              currentLocation={currentLocation}
            />
          </div>
        </div>
      )}

      {/* Character interaction overlay */}
      {activeGirl && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm">
          <div className="relative w-[640px] max-w-[95vw] rounded-xl border border-white/20 bg-black/80 p-4 shadow-lg">
            <CharacterOverlay
              girl={activeGirl}
              location={currentLocation}
              player={charPlayer}
              setPlayer={setCharPlayer}
              spendTime={(amt) => advanceHours(amt)}
              onClose={() => setActiveGirl(null)}
              onStartDialogue={(dialogue) => {
                setActiveGirl(null);
                setDialogue(dialogue);
              }}
              dayOfWeek={dayOfWeek}
              hour={time.hour}
              eventState={
                eventStateByGirl[activeGirl.name] ?? {
                  characterName: activeGirl.name,
                  eventHistory: [],
                  lastInteractionTime: 0,
                }
              }
              onEventTriggered={(eventId) =>
                handleEventTriggered(activeGirl.name, eventId)
              }
              darkMode
              onScheduleDate={(date) => {
                console.log("Scheduled date", date);
              }}
            />
          </div>
        </div>
      )}
    </div>
  );
}
