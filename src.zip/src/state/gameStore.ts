import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";

// === Types you already use ===
import type { Dialogue } from "@/types/dialogue";
import type {
  GameState,
  TimeState,
  PlayerStats,
  Relationships,
  LocationKey,
  RouteKey,
} from "@/types/game";

// === Daily goals ===
import type { DailyGoal } from "@/data/goals";
import { GOAL_POOL } from "@/data/goals";

// === Dialogue registry (for nextDialogueId branching) ===
import { getDialogueById } from "@/data/dialogues/registry";

// === Constants ===
const HOURS_PER_DAY = 24 as const;
const SAVE_VERSION = 5;

// === GameStore type ===
export type GameStore = {
  // Flow / Scene
  gameState: GameState;
  setGameState: (s: GameState) => void;

  // Time / World
  time: TimeState;
  setTime: (t: Partial<TimeState>) => void;
  nextDay: () => void;
  advanceHours: (hours: number) => void;

  // Location / Route
  currentLocation: LocationKey;
  setLocation: (loc: LocationKey) => void;
  currentRoute: RouteKey;
  setRoute: (r: RouteKey) => void;

  // Player / Stats
  player: PlayerStats;
  setPlayer: (p: Partial<PlayerStats>) => void;

  // Relationships
  relationships: Relationships;
  setRelationships: (r: Partial<Relationships>) => void;

  // Flags (for one-time events, e.g. “met_iris”)
  flags: Record<string, boolean>;
  setFlag: (k: string, v: boolean) => void;

  // Dialogue
  currentDialogue: Dialogue | null;
  dialogueIndex: number;
  setDialogue: (d: Dialogue | null) => void;
  advanceDialogue: () => void;
  beginDialogueById: (id: string) => void;

  // Resources
  canSpend: (cost: number) => boolean;
  spendEnergy: (cost: number) => boolean;
  addMoney: (delta: number) => void;

  // Daily goals
  todayGoals: DailyGoal[];
  completedGoalIds: string[];
  rollDailyGoals: (count?: number) => void;
  completeGoal: (id: string) => void;

  // Reset
  resetToMainMenu: () => void;
};

// === Defaults ===
const DEFAULTS: Pick<
  GameStore,
  | "gameState"
  | "time"
  | "currentLocation"
  | "currentRoute"
  | "player"
  | "relationships"
  | "currentDialogue"
  | "dialogueIndex"
  | "flags"
  | "todayGoals"
  | "completedGoalIds"
> = {
  gameState: "mainMenu",
  time: { dayIndex: 1, hour: 8 },
  currentLocation: "Apartment" as LocationKey,
  currentRoute: null as unknown as RouteKey,
  player: {
    money: 100,
    energy: 100,
    charm: 5,
    strength: 5,
    intelligence: 5,
  } as PlayerStats,
  relationships: { affection: {}, trust: {} } as Relationships,
  currentDialogue: null,
  dialogueIndex: 0,
  flags: {},
  todayGoals: [],
  completedGoalIds: [],
};

// === Migration helper (for persistence) ===
function migrateSave(s: any): any {
  const state = s?.state ?? s ?? {};
  return {
    version: SAVE_VERSION,
    state: {
      ...DEFAULTS,
      ...state,
      time: { ...DEFAULTS.time, ...(state.time ?? {}) },
      player: { ...DEFAULTS.player, ...(state.player ?? {}) },
      relationships: {
        ...DEFAULTS.relationships,
        ...(state.relationships ?? {}),
      },
      flags: { ...(state.flags ?? {}) },
      todayGoals: Array.isArray(state.todayGoals) ? state.todayGoals : [],
      completedGoalIds: Array.isArray(state.completedGoalIds)
        ? state.completedGoalIds
        : [],
    },
  };
}

// === Store implementation ===
export const useGameStore = create<GameStore>()(
  persist(
    (set, get) => ({
      ...DEFAULTS,

      // --- Flow ---
      setGameState: (s) => set({ gameState: s }),

      // --- Time / Day ---
      setTime: (t) =>
        set((st) => ({
          time: { ...st.time, ...t },
        })),

      advanceHours: (hours: number) => {
        const s = get();
        let newHour = s.time.hour + hours;
        let newDay = s.time.dayIndex;
        if (newHour >= HOURS_PER_DAY) {
          newDay += Math.floor(newHour / HOURS_PER_DAY);
          newHour = newHour % HOURS_PER_DAY;
        }
        set({ time: { dayIndex: newDay, hour: newHour } });
      },

      nextDay: () => {
        const s = get();
        set({
          time: { dayIndex: s.time.dayIndex + 1, hour: 8 },
        });
        get().rollDailyGoals(2);
      },

      // --- Location ---
      setLocation: (loc) => set({ currentLocation: loc }),
      setRoute: (r) => set({ currentRoute: r }),

      // --- Player ---
      setPlayer: (p) => set((s) => ({ player: { ...s.player, ...p } })),

      // --- Relationships ---
      setRelationships: (r) =>
        set((s) => ({
          relationships: { ...s.relationships, ...r },
        })),

      // --- Flags ---
      setFlag: (k, v) =>
        set((s) => ({
          flags: { ...s.flags, [k]: v },
        })),

      // --- Dialogue ---
      setDialogue: (d) =>
        set((s) => ({
          currentDialogue: d,
          dialogueIndex: d ? 0 : s.dialogueIndex,
          gameState: d ? "dialogue" : s.gameState,
        })),

      advanceDialogue: () =>
        set((s) => {
          const d = s.currentDialogue;
          if (!d) return {};
          const next = s.dialogueIndex + 1;
          if (next >= d.lines.length) {
            return {
              currentDialogue: null,
              dialogueIndex: 0,
              gameState: "playing",
            };
          }
          return { dialogueIndex: next };
        }),

      beginDialogueById: (id: string) => {
        const d = getDialogueById(id);
        if (!d) return;
        set({
          currentDialogue: d,
          dialogueIndex: 0,
          gameState: "dialogue",
        });
      },

      // --- Resources ---
      canSpend: (cost) => {
        const s = get();
        return s.player.energy - cost >= 0;
      },
      spendEnergy: (cost) => {
        const s = get();
        const newEnergy = s.player.energy - cost;
        if (newEnergy < 0) return false;
        set({
          player: {
            ...s.player,
            energy: Math.max(0, Math.min(100, newEnergy)),
          },
        });
        return true;
      },
      addMoney: (delta) => {
        const s = get();
        set({
          player: { ...s.player, money: Math.max(0, s.player.money + delta) },
        });
      },

      // --- Daily goals ---
      rollDailyGoals: (count = 2) =>
        set(() => {
          const pool = [...GOAL_POOL];
          const picked: DailyGoal[] = [];
          while (picked.length < count && pool.length) {
            const i = Math.floor(Math.random() * pool.length);
            picked.push(pool.splice(i, 1)[0]);
          }
          return { todayGoals: picked, completedGoalIds: [] };
        }),

      completeGoal: (id) =>
        set((s) => {
          if (s.completedGoalIds.includes(id)) return {};
          return { completedGoalIds: [...s.completedGoalIds, id] };
        }),

      // --- Reset ---
      resetToMainMenu: () => set({ ...DEFAULTS, gameState: "mainMenu" }),
    }),
    {
      name: "hotv-game-store",
      version: SAVE_VERSION,
      storage: createJSONStorage(() => localStorage),
      migrate: migrateSave as any,
      partialize: (s) => ({
        gameState: s.gameState,
        time: s.time,
        currentLocation: s.currentLocation,
        currentRoute: s.currentRoute,
        player: s.player,
        relationships: s.relationships,
        flags: s.flags,
        todayGoals: s.todayGoals,
        completedGoalIds: s.completedGoalIds,
        currentDialogue: s.currentDialogue,
        dialogueIndex: s.dialogueIndex,
      }),
    }
  )
);
